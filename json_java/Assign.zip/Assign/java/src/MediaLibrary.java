
import java.util.ArrayList;
import java.util.Iterator;


public class MediaLibrary{
    ArrayList<MediaDescription> theMedia;
    int musicCount, videoCount;
    
    public MediaLibrary() {
        theMedia = new ArrayList<MediaDescription>();
    }
    
    public boolean add(MediaDescription aClip) {
        theMedia.add(aClip);
        if (aClip.getMediaType() != null && aClip.getMediaType().equals("Music")) {
            musicCount++;
        } else if (aClip.getMediaType() != null && aClip.getMediaType().equals("Video")) {
            videoCount++;
        }
        System.out.println("Adding: " + aClip.getTitle());
        return true;
        // A method to add a new song or video the library. True is returned when the request is successful.
    }
    
    public boolean remove(String aTitle) {
        MediaDescription removal = null;
        for (MediaDescription m : theMedia) {
            if (m.getTitle() != null && m.getTitle().equals(aTitle)) {
                System.out.println("Removing: " + m.getTitle());
                removal = m;
                break;
            }
        }
        theMedia.remove(removal);
        return true;
        // A method to remove the named MediaDescription from the library.
    }
    
    public MediaDescription get(String aTitle) {
        for (MediaDescription m : theMedia) {
            if (m.getTitle() != null && m.getTitle().equals(aTitle)) {
                return m;
            }
        }
        // Returns the media description with title aTitle.
        return null;
    }
    
    public String[] getTitles() {
        String[] mediaArray = new String[theMedia.size()];
        int count = 0;
        
        for (MediaDescription m : theMedia) {
            if (m.getMediaType() != null) {
                mediaArray[count] = m.getTitle();
                count++;
            }
        }
        
        return mediaArray;
        // Returns an array of strings, which are all of the titles in the library.
    }
    
    public String[] getMusicTitles() {
        String[] musicArray = new String[musicCount];
        int count = 0;
        
        for (MediaDescription m : theMedia) {
            if (m.getMediaType() != null && m.getMediaType().equals("Music")) {
                musicArray[count] = m.getTitle();
                count++;
            }
        }
        
        return musicArray;
        // Returns an array of strings, which are all of the music titles in the library.
    }
    
    public String[] getVideoTitles() {
        String[] videoArray = new String[videoCount];
        int count = 0;
        
        for (MediaDescription m : theMedia) {
            if (m.getMediaType() != null && m.getMediaType().equals("Video")) {
                videoArray[count] = m.getTitle();
                count++;
            }
        }
        
        return videoArray;
        // Returns an array of strings, which are all of the video titles in the library.
    }
    
    public ArrayList<MediaDescription> getTheMedia() {
        return theMedia;
    }
}