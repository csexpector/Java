// file: MemIndexOutOfBoundsException.java

public class MemIndexOutOfBoundsException extends IndexOutOfBoundsException{

	public MemIndexOutOfBoundsException(){
		
		super();

	}

		

	public MemIndexOutOfBoundsException(String s){

		super( s );

	}

}




