
This is an example of creating processes and pipes in Windows.

The code was taken (and modified) from:

http://msdn.microsoft.com/en-us/library/windows/desktop/ms682499(v=vs.85).aspx

The files can be added to a project in Visual Studio.
The parent expects to read a filename as a command-line argument.
This can be set in the project properties. 


