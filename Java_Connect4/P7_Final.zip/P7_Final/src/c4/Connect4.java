package c4;

/**
 * Launches a game of Connect 4.
 * @author Joe Zachary
 */
public class Connect4
{
    public static void main (String[] args)
    {
        C4Display display = new C4Display();
        display.setVisible(true);
    }
}
